# Todos-List
A Todo List Application. A simple CRUD application using React and Firebase.
                
# Demo
[![TodosList](/public/portfolio4.jpg)](https://www.youtube.com/watch?v=OlyA7Q0qPPE&t=62s)

# Tech Stack
- React
- React Hooks
- Firebase
- Node.js